# UCM for Intel Geminilake chromebooks using SOF.

* sof-glkda7219max: Original files [here](https://github.com/eupnea-linux/ucm-configs/tree/main/upstream/octopus/blooguard/sof-glkda7219max.1loc).
* sof-glkrt5682max: Original files [here](https://github.com/eupnea-linux/ucm-configs/tree/main/upstream/octopus/apele/sof-glkrt5682max.1loc).
* sof-cs42l42: Original files [here](https://github.com/eupnea-linux/ucm-configs/tree/main/upstream/octopus/fleex/sof-cs42l42.1loc.1mic).
