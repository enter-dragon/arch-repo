# UCM for Intel Jasperlake chromebooks using SOF.

* sof-rt5682:
	* Regular HiFi: Original files [here](https://github.com/eupnea-linux/ucm-configs/tree/main/upstream/dedede/botenflex/sof-rt5682.rt1015.1mic.botenflex).
	* Magolor: Original files [here](https://github.com/eupnea-linux/ucm-configs/tree/main/upstream/dedede/magolor/sof-rt5682.magolor.rt1015p.2mic).
	* Magpie: Original files [here](https://github.com/eupnea-linux/ucm-configs/tree/main/upstream/dedede/magpie/sof-rt5682.magpie.rt1015p.1mic).
* sof-cs42l42: Original files [here](https://github.com/eupnea-linux/ucm-configs/tree/main/upstream/dedede/cret/sof-cs42l42.1loc.1mic).
* sof-da7219max98: Original files [here](https://github.com/eupnea-linux/ucm-configs/tree/main/upstream/dedede/bugzzy/sof-da7219max98360a.bugzzy.1mic).
