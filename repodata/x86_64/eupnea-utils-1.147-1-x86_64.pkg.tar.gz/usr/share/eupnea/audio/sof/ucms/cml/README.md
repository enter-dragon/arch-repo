# UCM for Intel Cometlake chromebooks using SOF.

* sof-cmlda7219max: Original files [here](https://github.com/eupnea-linux/ucm-configs/tree/main/upstream/hatch/common/sof-cmlda7219max.base).
* sof-rt5682: Original files [here](https://github.com/eupnea-linux/ucm-configs/tree/main/upstream/hatch/common/sof-rt5682.base).
* sof-cmlrt1011rt5682: Original files [here](https://github.com/eupnea-linux/ucm-configs/tree/main/upstream/hatch/common/sof-cml_rt1011_rt5682.base).
