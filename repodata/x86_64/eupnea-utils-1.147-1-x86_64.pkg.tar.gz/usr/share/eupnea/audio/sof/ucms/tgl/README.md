# UCM for Intel Tigerlake chromebooks using SOF.

* sof-rt5682: 
	* max98373 (regular HiFi): Original files [here](https://github.com/eupnea-linux/ucm-configs/tree/main/upstream/volteer/voxel/sof-rt5682.max98373.voxel).
	* Delbin (max98373/2345 HDMI): Original files [here](https://github.com/eupnea-linux/ucm-configs/tree/main/upstream/volteer/delbin/sof-rt5682.max98373.delbin).
    * Eldrid: Original files [here](https://github.com/eupnea-linux/ucm-configs/tree/main/upstream/volteer/eldrid/sof-rt5682.eldrid).
	* Elemi (max98357a): Original files [here](https://github.com/eupnea-linux/ucm-configs/tree/main/upstream/volteer/chronicler/sof-rt5682.chronicler).
	* rt1011 (Hifi-Lillipup): Original files [here](https://github.com/eupnea-linux/ucm-configs/tree/main/upstream/volteer/lillipup/sof-rt5682.lillipup).
