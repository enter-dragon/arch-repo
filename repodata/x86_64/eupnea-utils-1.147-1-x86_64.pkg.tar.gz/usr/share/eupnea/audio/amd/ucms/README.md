# UCM for AMD chromebooks using acp/acp3x.

Original files:
* acpd7219m98357(Stoneyridge): [here](https://chromium.googlesource.com/chromiumos/overlays/board-overlays/+/refs/heads/main/overlay-grunt/chromeos-base/chromeos-bsp-grunt/files/ucm-config/acpd7219m98357.1mic/).
* HDA ATI HDMI(Stoneyridge HDMI): [here](https://chromium.googlesource.com/chromiumos/overlays/board-overlays/+/refs/heads/main/overlay-grunt/chromeos-base/chromeos-bsp-grunt/files/ucm-config/HDA%20ATI%20HDMI/).
* acp3xalc5682m98(Ryzen 3000): [here](https://github.com/alsa-project/alsa-ucm-conf/tree/master/ucm2/AMD/acp3xalc5682m98).
* acp3xalc5682101(Vilboz): [here](https://github.com/eupnea-linux/ucm-configs/tree/main/upstream/zork/vilboz/acp3xalc56821015.1mic.vilboz).
* HD-Audio Generic(Ryzen 3000 HDMI): [here](https://github.com/eupnea-linux/ucm-configs/tree/main/upstream/zork/common/HD-Audio%20Generic).
