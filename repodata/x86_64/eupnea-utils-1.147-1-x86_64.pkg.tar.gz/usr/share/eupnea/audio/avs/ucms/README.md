# UCM for Intel Apollolake/Skylake/Kabylake chromebooks using AVS.

Original files:
* da7219, max98357a, dmic, hdaudio: [here](https://github.com/eupnea-linux/ucm-configs/tree/main/upstream/coral/common/1mic).
* max98373: [NOCTURNE recovery image](https://dl.google.com/dl/edgedl/chromeos/recovery/chromeos_15117.112.0_nocturne_recovery_stable-channel_mp.bin.zip).
* max98927: [here](https://github.com/eupnea-linux/ucm-configs/tree/main/upstream/rammus/common/avs_max98927).
* nau8825, ssm4567: written from scratch.
